package com.example.dao;

/**
 *
 * 
 */
public interface WorldDao extends CountryDao,CityDao {

}
