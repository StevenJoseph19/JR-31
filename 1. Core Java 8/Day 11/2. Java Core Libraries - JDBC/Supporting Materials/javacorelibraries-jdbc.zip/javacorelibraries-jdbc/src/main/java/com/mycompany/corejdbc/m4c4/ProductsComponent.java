package com.mycompany.corejdbc.m4c4;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;

public class ProductsComponent {

	public void printProductList(double lowPrice, double highPrice) throws Exception {

//		try (Connection connection = DriverManager.getConnection(
//				"jdbc:mysql://localhost:3306/classicmodels?user=root&password=password&serverTimezone=UTC");)

			
			
			

		

//				while (resultSet.next()) {
//
//					String name = resultSet.getString("productName");
//					System.out.println(name);
//				}

			}
		
	}

//}
