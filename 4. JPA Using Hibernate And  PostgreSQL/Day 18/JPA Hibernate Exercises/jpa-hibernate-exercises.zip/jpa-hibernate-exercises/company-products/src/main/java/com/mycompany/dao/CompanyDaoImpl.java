package com.mycompany.dao;

import javax.persistence.EntityManagerFactory;

import com.mycompany.model.Company;

public class CompanyDaoImpl implements CompanyDao {
    private EntityManagerFactory entityManagerFactory;

    public CompanyDaoImpl(EntityManagerFactory entityManagerFactory) {
        this.entityManagerFactory = entityManagerFactory;
    }

    @Override
    public Company findByIdFetchProducts(Long id) {
        throw new UnsupportedOperationException("I'm still not implemented!");
    }
}
