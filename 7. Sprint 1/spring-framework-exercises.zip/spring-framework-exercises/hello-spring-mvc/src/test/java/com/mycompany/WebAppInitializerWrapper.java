package com.mycompany;

import com.mycompany.config.RootConfig;
import com.mycompany.config.WebAppInitializer;
import com.mycompany.config.WebConfig;

class WebAppInitializerWrapper extends WebAppInitializer {
	public String[] getServletMappings() {
        return super.getServletMappings();
		
	}

	public Class[] getRootConfigClasses() {
        return super.getRootConfigClasses();

	}

	public Class<?>[] getServletConfigClasses() {
        return super.getServletConfigClasses();
	
	}
}