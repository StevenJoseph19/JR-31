SELECT *
FROM employees;