package com.mycompany.dao;

import com.mycompany.model.Account;

public interface AccountDao {
    Account findById(Long id);
}
