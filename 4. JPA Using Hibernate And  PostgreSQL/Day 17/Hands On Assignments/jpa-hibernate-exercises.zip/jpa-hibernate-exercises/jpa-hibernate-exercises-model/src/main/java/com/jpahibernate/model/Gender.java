package com.jpahibernate.model;

public enum Gender {
    MALE,
    FEMALE
}
