package com.mycompany.conferenceapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConferenceAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
