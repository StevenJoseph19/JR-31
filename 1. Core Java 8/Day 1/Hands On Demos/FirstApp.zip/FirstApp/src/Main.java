
public class Main {

	/*
	 * This is a first comment line. 
	 * This is the second comment line.
	 // This is a line comment.
	 * 
	 */
	public static void main(String[] args) {

		System.out.println("First line from app"); // This is a line comment.
//		System.out.println("Second line from app");
		// This is a stand alone line comment.
//		System.out.println("Third line from app");

		System.out.println(/* "Third line from app" */ "This is a different text.");
	}

}
