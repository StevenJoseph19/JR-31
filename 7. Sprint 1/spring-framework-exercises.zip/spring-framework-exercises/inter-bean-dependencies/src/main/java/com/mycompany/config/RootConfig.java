package com.mycompany.config;

import com.mycompany.TestDataGenerator;
import com.mycompany.dao.AccountDao;
import com.mycompany.dao.impl.FakeAccountDao;
import com.mycompany.service.AccountService;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

/**
 * todo: Refactor {@link RootConfig} in order to user inter-bean dependencies properly.
 */

public final class RootConfig {

    @Bean
    public AccountService accountService() {
    	throw new UnsupportedOperationException("It's your job to implement this method!");
    }

    @Bean
    public final AccountDao fakeAccountDao() {
    	throw new UnsupportedOperationException("It's your job to implement this method!");
    }

    @Bean
    private TestDataGenerator dataGenerator() {
    	throw new UnsupportedOperationException("It's your job to implement this method!");
    }
}
