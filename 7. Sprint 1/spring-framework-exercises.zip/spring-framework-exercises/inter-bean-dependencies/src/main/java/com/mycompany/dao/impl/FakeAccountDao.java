package com.mycompany.dao.impl;

import com.mycompany.TestDataGenerator;
import com.mycompany.dao.AccountDao;
import com.mycompany.model.Account;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class FakeAccountDao implements AccountDao {
    private final TestDataGenerator dataGenerator;

    @Override
    public Account findById(Long id) {
        Account account = dataGenerator.generateAccount();
        account.setId(id);
        return account;
    }
}
